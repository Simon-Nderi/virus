from django.contrib import admin
# from . models import textlang

# Register your models here.

# admin.site.register(textlang)