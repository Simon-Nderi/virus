# Language_Translator_Webapp

[![forthebadge made-with-python](http://ForTheBadge.com/images/badges/made-with-python.svg)](https://www.python.org/)
[![ForTheBadge built-with-love](http://ForTheBadge.com/images/badges/built-with-love.svg)](http://kambojtarun.pythonanywhere.com/)<br>
![made-with-HTML](https://img.shields.io/badge/HTML-5.0-ff5230?style=for-the-badge&logo=HTML5)
![made-with-Bootstrap](https://img.shields.io/badge/Bootstrap-4.0-7f50b5?style=for-the-badge&logo=Bootstrap)
![made-with-Django](https://img.shields.io/badge/Django-3.0-43993d?style=for-the-badge&logo=Django)
![made-with-IBMWatson](https://img.shields.io/badge/Watson-4.5-8682ff?style=for-the-badge&logo=IBM)

This is a language translator which allows you to translate text of one language to another. Click [here](http://languageinterpreter.herokuapp.com) to try by yourself.
